import Database.DBConnect;
import java.util.Arrays;
import org.knowm.xchart.QuickChart;
import org.knowm.xchart.SwingWrapper;
import org.knowm.xchart.XYChart;
import java.sql.Array;
import java.sql.ResultSet;
import java.sql.Statement;
import java.util.ArrayList;
import java.util.LinkedList;
import java.util.List;
import javax.swing.SwingWorker;
import org.knowm.xchart.QuickChart;
import org.knowm.xchart.SwingWrapper;
import org.knowm.xchart.XYChart;
import array.subArray;

import static array.dou_ListtoArray.dou_ListtoArray;
import static array.str_ListtoArray.str_ListtoArray;

//
//public class ECG_live {
  //  public static void main(String[] args) throws InterruptedException {

        // Create chart
      //  final XYChart chart = QuickChart.getChart("ECG Demo", "ms", "mV", "ECG", data[0], data[1]);
        // Show it
       // final SwingWrapper<XYChart> sw = new SwingWrapper<XYChart>(chart);
        //sw.displayChart();

        //while (true) {
          //  Thread.sleep(10);
           // data = new double[][]{subArray.subArray(xdata, start, start+99), subArray.subArray(ydata, start, start++ +99)};
           // chart.updateXYSeries("ECG", data[0], data[1], null);
           // sw.repaintChart();
  //      }
 //   }
//}


